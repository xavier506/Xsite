Thank you very much for download and choose this template. Here is some information about use this template.

How to set the countdown timer?
=> For change or set your countdown date just go to js/script.js file. Open it by any text editor. You will find line no 9.
newYear = new Date(2015, 12-1, 25) . Just change it to your website lunch date and save it. 

How to set email address for receive subscriber & contact information?
=> On the main folder you will find a file named contact.php. Open it by any text editor. At line number 4 and 5 you will find like 

$admin_email = "yourname@email.com";
$from_name   = "Site Coming Soon";

set your email address and from name. and save it. That's it.

Once again thanks for choosing this template. You can contact any time with me by 

email: a.a.mahin@gmail.com

or 

Facebook: http://www.fb.com/a.a.mahim

or

Skype: a.a.mahin